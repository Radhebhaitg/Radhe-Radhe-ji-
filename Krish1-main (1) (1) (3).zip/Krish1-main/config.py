BOT_NAME = "Luminatbot"
API_ID    = 21567814
API_HASH  = "cd7dc5431d449fd795683c550d7bfb7e"
BOT_TOKEN = "7662813243:AAEA3yIU_BZTCHR-lEXRFBelPfDdubYuRFA"
#MONGO_URI = "mongodb+srv://psrathore1155:<db_password>@cluster0.rpaat.mongodb.net/"
MONGO_URI = "mongodb+srv://mrnobody:modernhackers@mrnobody.q8e87ij.mongodb.net/?retryWrites=true&w=majority&appName=MrNobody"
